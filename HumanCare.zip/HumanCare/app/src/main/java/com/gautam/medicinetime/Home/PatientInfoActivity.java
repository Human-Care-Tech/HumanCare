package com.gautam.medicinetime.Home;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

import com.gautam.medicinetime.R;

public class PatientInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_info);


        EditText nameEditText = (EditText) findViewById(R.id.full_name);
        String fullName = nameEditText.getText().toString();

        EditText currentWeightEditText = (EditText) findViewById(R.id.weight);
        String weight = currentWeightEditText.getText().toString();

        EditText heightEditText = (EditText) findViewById(R.id.height);
        String height = heightEditText.getText().toString();


        EditText ageEditText = (EditText) findViewById(R.id.age);
        String age = ageEditText.getText().toString();

        EditText phoneEditText = (EditText) findViewById(R.id.Phone);
        String phone = phoneEditText.getText().toString();

        EditText addressEditText = (EditText) findViewById(R.id.address);
        String address = addressEditText.getText().toString();

        RadioButton maleBtn = findViewById(R.id.male);
        RadioButton femaleBtn = findViewById(R.id.female);

        String gender = " ";
        if (maleBtn.isChecked()) {
            gender = "Male";
        } else if (femaleBtn.isChecked()) {
            gender = "Female";
        }

        Button submit = findViewById(R.id.submit_info_form);
        String finalGender = gender;
        submit.setOnClickListener(view -> {
            Intent intent = new Intent(PatientInfoActivity.this, PatientProfileActivity.class );
            intent.putExtra("name", fullName);
            intent.putExtra("age", age);
            intent.putExtra("phone", phone);
            intent.putExtra("address", address);
            intent.putExtra("weight", weight);
            intent.putExtra("height", height);
            intent.putExtra("gender", finalGender);
            startActivity(intent);
        });
    }
}
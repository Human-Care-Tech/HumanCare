package com.gautam.medicinetime.Home;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.gautam.medicinetime.R;

public class Appointment_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

    }
}
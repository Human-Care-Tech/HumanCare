# HumanCare

# HumanCare Team Agreement
Project Prep #1
Team Members



Ghadeer khasawneh
Naim Alomari 
Rawan alazazi
Mohammad AlKhaleel
Deyaa alpozan 
Abrar algour
Adham alomari
Abd kafawen 





## Cooperation Plan
What are the key strengths of each person on the team?
- Rawan Alazazi: Cummunication, planning, team work,problrm solving, leadership.
- mohammad alkhaleel: hard working, problem solving, team work, supporting other team members.
- Naim Alomari : creativity, brain storming, team work, research.
- abd kafawen : team work, research, communication.
- adham alomari : problrm solving, research,  creativity
- abrar algour : planning, hard working, supporting other team member,  english verbs.
- deyaa alpozan : professional developer, brain storming, english verbs , sweet heart.
- ghadeer khasawneh : communication, creativity , hard working, planning,  english verbs.



How can you best utilize these strengths in the execution of your project?
We will utilize all of our strengths together to support each others in each step of the project execution.
In which professional competencies do you each want to develop greater strength?
We all need to improve our coding skills.
Knowing that every person in your team needs to understand all aspects of the project, how do you plan to approach the day-to-day work?
Dividing the work between the team members, we are four members, each two members will work on different task as a driver and navigator, at the end of the day we will discuss the progress that we have done and planning for the next day.



## Conflict Plan
What will be your group’s process to resolve conflict, when it arises?
We will work together to solve any conflict, I hope we don't have any conflicts, in case we have any problem, I have the responsibilty to solve it intellectually.
What will your team do if one person is taking over the project and not letting the other members contribute?
We all want to pass and to be successful, surely we will talk to that person in a very good way to convince him/her that it's a collaboration work, everyone should participate.
How will you raise concerns to members who are not adequately contributing?
I will keep telling them that we will not succeed if they don't contribute and did their work as planned.



## Communication Plan:
What hours will you be available to communicate?
We will be available during the class hours and on zoom after class.
What platforms will you use to communicate (ie. Slack, phone …)?
Slack, Zoom,and Discord
How often will you take breaks?
10 minutes break each hours, and 1 hour for lunch break.
What is your plan if you start to fall behind?
We will work intesively out the class hours.
How will you communicate after hours and on the weekend?
On slack.
What is your strategy for ensuring everyone’s voice is heard?
One person will talk and the other's will listen.
How will you ensure that you are creating a safe environment where everyone feels comfortable speaking up?
Everyone should respect the other and listen to their ideas and opinions.
Work Plan
How you will identify tasks, assign tasks, know when they are complete, and manage work in general?
Using planning for every day tasks github to track our progress and TODO work, in addition to work we have done.
What project management tool will be used?
github


## Git Process
What components of your project will live on GitHub?
all files except .env file, we will add a .envSample file.
How will you share the repository with your teammates?
I created an organization on GitHub and I've invited them to it.
What is your Git flow?
One person creates the repo, the other members can clone it and work on their local machine in different branch, they will push their work and merge it on the development branch, at the last day of work after finishing everything we will merge from the development branch to the main.
Will you be using a PR review workflow? If so, consider:
How many people must review a PR?
The team members.
Who merges PRs?
Team members
How often will you merge?
after finishing all features of the project
How will you communicate that it’s time to merge?
Via slack or zoom or discord.
